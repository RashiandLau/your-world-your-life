# Local life simulation core / 手元で動く人生生成の中核

## 日本語

このパッケージは、サイトと同じ人生生成のコードと資料を Node 上で実行します。通信はせず、鍵や登録も要りません。料金、利用枠、使用履歴の送信もありません。結果は計算上の人生であり、実在する人の予測ではありません。統計のない部分は推計を含みます。

```js
const core = require('./api/core');
const one = core.simulate(417, { locale: 'ja', era: 'now', method: 'births' });
const many = core.batch(417, { count: 3, locale: 'ja' });
const ages = core.experienceAges(417, { locale: 'ja' });
const family = core.lineage(417, { era: 'past', year: 1960, generations: 3 });
```

`simulate(seed, options)` は `{contractVersion, life, experiences}` を返します。`life` は画面と同じ人生記録です。ただし、実行時刻を表す `ended` は含めません。`experiences` には、主な出来事の年齢、年、種類、文章、文の色調、記録番号、関係する人物番号、資料を入れます。`experienceAges` はその一覧だけを返します。通常の表示で自殺が含まれる場合、`life.death.supportLine` に相談先へつながる案内が入ります。

`batch(seed, {count, ...options})` は `{contractVersion, seed, results}` を返します。`results` の各要素に使用した種と `simulate` の結果を入れます。最初の人は指定した種をそのまま使います。`count` は 1〜100 です。

`lineage(seed, {generations, ...options})` は `{contractVersion, seed, nodes, stopped}` を返します。`nodes` には各世代から子どもを一人ずつ選んだ人生を入れます。各節点の `id` と `parentId`、`sourceChildId` は親の `childOutcomes` とつながります。子どもの名前、性別、生年は親の記録から引き継ぎます。それ以降の人生は、新しい種で生まれ直した**条件付きの模擬人生**です。親が亡くなった時点で生存し、1950〜2025 年に生まれた子どもがいない場合は、そこで止まり、`stopped` は `no_eligible_child` になります。子の模擬人生も親の死亡時まで続くよう、最大32回抽選します。一致する人生が出なければ `no_consistent_continuation` で止まります。子どもの出生国は記録に残っていないため、親の記録にある居住国を使います。`generations` は 1〜3 です。系譜では `era: 'past'` を指定してください。

種は 0〜4294967295 の整数です。設定できる項目は `locale` (`ja` または `en`)、`era` (`past`、`now`、`future`)、`method` (`births` または `pop`)、`country` (小文字の3文字の国コード)、`year` (`past` の場合のみ 1950〜2025)、`gentle`、`edu`、`stateless` です。`edu` は `now` の場合のみ使えます。不明な項目や無効な値はエラーになります。

契約の版は `CONTRACT_VERSION` と各結果の `contractVersion` で確認できます。同じ版、同じ種、同じ設定、同じ資料なら、結果は一致します。日替わりの話題は契約内で 2026-11-06 に固定しました。画面との照合にもこの `themeDate` を使います。資料や生成コードを更新すると、版が同じでも内容が変わる場合があります。

## English

This package runs the site's own simulation code and bundled data in Node. It makes no network calls and needs no account or key. There are no fees, quotas, or usage reports. Each life is a simulation, not a prediction about a real person; data gaps include estimates.

`simulate(seed, options)` returns `{contractVersion, life, experiences}`. The `life` is the browser's record without the execution timestamp `ended`. Each experience includes its age, year, type, text, tone, event ID, related person ID, and source information. `experienceAges` returns only that list. For a suicide outcome in normal mode, `life.death.supportLine` contains a support message.

`batch(seed, {count, ...options})` returns `{contractVersion, seed, results}`. Each result includes its derived seed and the `simulate` result. The first result uses the supplied seed. `count` must be 1–100.

`lineage(seed, {generations, ...options})` returns `{contractVersion, seed, nodes, stopped}`. It follows one recorded child per generation. A node's `id`, `parentId`, and `sourceChildId` connect to the parent's `childOutcomes`. The child's name, sex, and birth year come from that record. Later events are a **conditional simulation**, not an observed continuation. It stops with `no_eligible_child` if no living child was born in 1950–2025. Up to 32 deterministic draws keep the child's simulated life consistent with being alive when the parent died; `no_consistent_continuation` means none matched. A child's country at birth is not stored, so the parent's recorded residence is used as an assumption. `generations` must be 1–3 and `era` must be `past`.

The seed is an integer from 0 to 4294967295. Options are `locale` (`ja` or `en`), `era` (`past`, `now`, or `future`), `method` (`births` or `pop`), `country` (lowercase three-letter ISO code), `year` (1950–2025 with `past` only), and the booleans `gentle`, `edu`, and `stateless`. `edu` requires `now`. Unknown fields and invalid values fail validation.

Read `CONTRACT_VERSION` or the result's `contractVersion` for the contract version. The same version, seed, options, and bundled data produce the same result. The daily topic uses a fixed contract date of 2026-11-06; use the same `themeDate` when comparing with browser gameplay. Updating the bundled data or engine may change results even when the contract version stays the same.
