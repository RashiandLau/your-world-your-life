'use strict';

// The local package runs the same scripts as the browser. Nothing is fetched or sent.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const i18n = require('./i18n');

const CONTRACT_VERSION = '1.0.0';
const THEME_DATE = '2026-11-06';
const assetRoot = path.resolve(__dirname, '../../site/assets');
const assets = [
  'data', 'data_history', 'i18n', 'engine_i18n', 'money', 'engine',
  'lifetables', 'names', 'culture', 'joys', 'dialogue',
  'facts', 'history', 'causes', 'scripts', 'chains', 'memories', 'emotions'
];
const sources = assets.map(name => ({
  name: name + '.js', source: fs.readFileSync(path.join(assetRoot, name + '.js'), 'utf8')
}));
const allowedOptions = new Set(['locale', 'era', 'method', 'country', 'year', 'gentle', 'edu', 'stateless']);
const copy = value => JSON.parse(JSON.stringify(value));

function fail(key, locale, vars) {
  const language = locale === 'en' ? 'en' : 'ja';
  throw new TypeError(i18n.t(language, key, vars || {}));
}
function validateSeed(seed, locale) {
  if (!Number.isInteger(seed) || seed < 0 || seed > 0xffffffff) fail('seed', locale);
  return seed;
}
function validateOptions(value, extra) {
  if (value === undefined) value = {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail('options', 'ja');
  const permitted = new Set([...allowedOptions, ...(extra || [])]);
  for (const key of Object.keys(value)) if (!permitted.has(key)) fail('unknown', value.locale, { key });
  const options = { ...value };
  if (options.locale === undefined) options.locale = 'ja';
  if (options.era === undefined) options.era = 'now';
  if (options.method === undefined) options.method = 'births';
  if (!['ja', 'en'].includes(options.locale)) fail('locale', 'ja');
  if (!['past', 'now', 'future'].includes(options.era)) fail('era', options.locale);
  if (!['births', 'pop'].includes(options.method)) fail('method', options.locale);
  if (options.country !== undefined && (typeof options.country !== 'string' || !/^[a-z]{3}$/.test(options.country))) fail('country', options.locale);
  if (options.year !== undefined && (options.era !== 'past' || !Number.isInteger(options.year) || options.year < 1950 || options.year > 2025)) fail('year', options.locale);
  for (const key of ['gentle', 'edu', 'stateless']) if (options[key] !== undefined && typeof options[key] !== 'boolean') fail('boolean', options.locale, { key });
  if (options.edu === true && options.era !== 'now') fail('edu', options.locale);
  return options;
}
function engineSettings(options) {
  const { locale, count, generations, ...settings } = options;
  return { ...settings, themeDate: THEME_DATE };
}
function runtime(locale) {
  const window = {};
  const document = { documentElement: { lang: locale } };
  const context = vm.createContext({ window, document });
  for (const asset of sources) vm.runInContext(asset.source, context, { filename: asset.name, timeout: 10000 });
  if (!Array.isArray(window.COUNTRIES) || !window.COUNTRIES.length ||
      !window.COUNTRIES.every(country => country.vax_history && country.infl_history)) {
    throw new Error('Missing country history fields: vax_history, infl_history');
  }
  window.MEGURI.refreshData();
  return window.MEGURI;
}
function validateCountry(engine, options) {
  if (options.country && !engine.BY[options.country]) fail('unknownCountry', options.locale || 'ja', { country: options.country });
}
function publicRecord(record) {
  const life = copy(record);
  delete life.ended; // Browser record timestamp is display metadata, not a simulation result.
  return life;
}
function experiences(life) {
  return life.history.map(event => ({
    id: event.id, age: event.age, year: event.year, type: event.type,
    text: event.text, tone: event.tone, identity: event.identity,
    causeId: event.causeId, src: event.src, stat: event.stat
  }));
}
function simulate(seed, options) {
  validateSeed(seed, options && options.locale);
  const input = validateOptions(options);
  const engine = runtime(input.locale);
  validateCountry(engine, input);
  const life = publicRecord(engine.simulateFull(seed, engineSettings(input)));
  return { contractVersion: CONTRACT_VERSION, life, experiences: experiences(life) };
}
function derivedSeed(seed, index) {
  // Stable independent seeds; the first batch member uses the given seed.
  if (index === 0) return seed;
  let x = (seed + Math.imul(index, 0x9e3779b9)) >>> 0;
  x ^= x >>> 16; x = Math.imul(x, 0x85ebca6b);
  x ^= x >>> 13; x = Math.imul(x, 0xc2b2ae35);
  return (x ^ (x >>> 16)) >>> 0;
}
function batch(seed, options) {
  validateSeed(seed, options && options.locale);
  const input = validateOptions(options, ['count']);
  const count = input.count === undefined ? 2 : input.count;
  if (!Number.isInteger(count) || count < 1 || count > 100) fail('count', input.locale);
  const { count: unused, ...simulationOptions } = input;
  const results = Array.from({ length: count }, (_, i) => ({ seed: derivedSeed(seed, i), ...simulate(derivedSeed(seed, i), simulationOptions) }));
  return { contractVersion: CONTRACT_VERSION, seed, results };
}
function experienceAges(seed, options) {
  return simulate(seed, options).experiences;
}
function runDescendant(seed, options, source, parent) {
  const engine = runtime(options.locale);
  const childYear = parent.birthYear + source.born;
  const settings = { ...engineSettings(options), era: 'past', year: childYear, country: parent.residence || parent.iso };
  validateCountry(engine, settings);
  engine.setRandom(engine.rng(seed));
  const person = engine.birth(settings);
  person.auto = true;
  person.id = parent.id + '/' + source.id;
  person.name = source.fullName || source.name;
  person.given = source.name;
  person.family = source.family || person.family;
  person.firstSurname = source.firstSurname || person.firstSurname;
  person.birthFamily = person.family;
  person.sex = source.sex;
  person.le = Math.round((person.sex === 'f' ? person.birthSnapshot.leFemale : person.birthSnapshot.leMale) * 10) / 10;
  const parentKey = parent.sex === 'f' ? 'mom' : 'dad';
  person.parents[parentKey].name = parent.name;
  person.parents[parentKey].given = parent.given;
  person.parents[parentKey].age = source.born;
  const words = {
    birth: i18n.t(options.locale, 'lineageBirth', { name: person.name }),
    family: i18n.t(options.locale, 'lineageFamily', { parent: parent.name, given: person.given })
  };
  const birth = person.history.find(event => event.type === 'birth');
  const family = person.history.find(event => event.type === 'family_origin');
  if (birth) {
    const originalBirthText = birth.text;
    birth.people = [person.name, person.parents.mom.given, person.parents.dad.given];
    birth.text = words.birth;
    const birthLog = person.log.find(entry => entry.t === originalBirthText);
    if (birthLog) birthLog.t = words.birth;
  }
  if (family) { family.people = [person.parents.mom.given, person.parents.dad.given]; family.text = words.family; }
  person.story = null;
  let guard = 0;
  while (!person.ended && guard++ < 130) {
    if (person.pending) { engine.resolveAuto(person); continue; }
    engine.yearEnd(person);
    if (person.pending && !person.ended) engine.resolveAuto(person);
  }
  if (!person.ended) throw new Error(i18n.t(options.locale, 'unfinished', {}));
  return publicRecord(engine.record(person));
}
function lineage(seed, options) {
  validateSeed(seed, options && options.locale);
  const input = validateOptions(options, ['generations']);
  const generations = input.generations === undefined ? 2 : input.generations;
  if (!Number.isInteger(generations) || generations < 1 || generations > 3) fail('generations', input.locale);
  const { generations: unused, ...simulationOptions } = input;
  if (simulationOptions.era !== 'past') fail('lineageEra', simulationOptions.locale);
  const root = simulate(seed, simulationOptions);
  const nodes = [{ id: root.life.id, parentId: null, generation: 1, sourceChildId: null, life: root.life, experiences: root.experiences }];
  let stopped = null;
  for (let generation = 2; generation <= generations; generation++) {
    const parent = nodes[nodes.length - 1].life;
    const child = parent.childOutcomes.find(item => item.alive && parent.birthYear + item.born >= 1950 && parent.birthYear + item.born <= 2025 && item.sex && (item.fullName || item.name));
    if (!child) { stopped = 'no_eligible_child'; break; }
    // The parent record says this child was alive when the parent died. Draw
    // conditional continuations until the descendant record agrees with it.
    const baseSeed = derivedSeed(seed, generation - 1);
    let life = null;
    for (let attempt = 0; attempt < 32; attempt++) {
      const candidate = runDescendant(derivedSeed(baseSeed, attempt), simulationOptions, child, parent);
      if (candidate.death.year >= parent.death.year) { life = candidate; break; }
    }
    if (!life) { stopped = 'no_consistent_continuation'; break; }
    nodes.push({ id: life.id, parentId: parent.id, generation, sourceChildId: child.id, route: child.route, life, experiences: experiences(life) });
  }
  return { contractVersion: CONTRACT_VERSION, seed, nodes, stopped };
}

module.exports = { CONTRACT_VERSION, simulate, batch, lineage, experienceAges };
