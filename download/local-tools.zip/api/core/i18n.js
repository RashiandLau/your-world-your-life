'use strict';

const dictionaries = {
  ja: {
    seed: 'seed は 0 から 4294967295 までの整数にしてください。',
    options: 'options はオブジェクトにしてください。',
    unknown: '不明な設定: {key}',
    locale: 'locale は ja または en にしてください。',
    era: 'era の値が正しくありません。',
    method: 'method は births または pop にしてください。',
    country: 'country は小文字の3文字の国コードにしてください。',
    year: 'year は past のときに 1950〜2025 年から選んでください。',
    boolean: '{key} は真偽値にしてください。',
    edu: 'edu は now のときだけ使えます。',
    unknownCountry: 'この国コードは使えません: {country}',
    count: 'count は 1〜100 の整数にしてください。',
    generations: 'generations は 1〜3 の整数にしてください。',
    lineageEra: '系譜は past で生成してください。',
    unfinished: '人生の生成が終わりませんでした。',
    lineageBirth: '{name}が生まれました。',
    lineageFamily: '{parent}と幼い日々を過ごしました。'
  },
  en: {
    seed: 'seed must be an unsigned 32-bit integer.',
    options: 'options must be an object.',
    unknown: 'Unknown option: {key}',
    locale: 'locale must be ja or en.',
    era: 'era must be past, now, or future.',
    method: 'method must be births or pop.',
    country: 'country must be a lowercase three-letter ISO code.',
    year: 'year requires past era and 1950–2025.',
    boolean: '{key} must be boolean.',
    edu: 'edu requires now era.',
    unknownCountry: 'Unknown country: {country}',
    count: 'count must be 1–100.',
    generations: 'generations must be 1–3.',
    lineageEra: 'lineage requires past era.',
    unfinished: 'Simulation did not end.',
    lineageBirth: '{name} was born.',
    lineageFamily: '{parent} was part of {given}’s early life.'
  }
};

function t(locale, key, vars) {
  const text = dictionaries[locale][key];
  if (text === undefined) throw new Error('Missing core translation: ' + key);
  return text.replace(/\{([a-zA-Z][a-zA-Z0-9_]*)\}/g, (_, name) => String(vars[name]));
}

module.exports = { dictionaries, t };
