#!/usr/bin/env node
'use strict';

const core = require('../core');
const { t } = require('./i18n');

const common = new Set(['locale', 'era', 'method', 'country', 'year', 'gentle', 'edu', 'stateless']);
const boolean = new Set(['gentle', 'edu', 'stateless']);
const numeric = new Set(['seed', 'year', 'count', 'generations']);
const commands = { simulate: core.simulate, batch: core.batch, lineage: core.lineage };

function language(args) {
  const index = args.indexOf('--locale');
  return index >= 0 && args[index + 1] === 'en' ? 'en' : 'ja';
}

function inputError(key, locale, vars) {
  throw new TypeError(t(locale, key, vars));
}

function parse(args, locale) {
  const command = args[0];
  if (!Object.hasOwn(commands, command)) inputError('command', locale);
  const allowed = new Set([...common, 'seed']);
  if (command === 'batch') allowed.add('count');
  if (command === 'lineage') allowed.add('generations');
  const found = new Set();
  const options = {};
  let seed;
  for (let i = 1; i < args.length; i += 2) {
    const flag = args[i];
    const key = flag.startsWith('--') ? flag.slice(2) : '';
    if (!allowed.has(key)) inputError('flag', locale, { flag });
    if (found.has(key)) inputError('duplicate', locale, { flag });
    const raw = args[i + 1];
    if (raw === undefined || raw.startsWith('--')) inputError('missing', locale, { flag });
    found.add(key);
    let value = raw;
    if (numeric.has(key)) {
      if (!/^(0|[1-9][0-9]*)$/.test(raw) || !Number.isSafeInteger(Number(raw))) inputError('integer', locale, { flag });
      value = Number(raw);
    } else if (boolean.has(key)) {
      if (raw !== 'true' && raw !== 'false') inputError('boolean', locale, { flag });
      value = raw === 'true';
    }
    if (key === 'seed') seed = value;
    else options[key] = value;
  }
  if (seed === undefined) inputError('seedRequired', locale);
  return { command, seed, options };
}

function run(args, io = { out: text => process.stdout.write(text), err: text => process.stderr.write(text) }) {
  const locale = language(args);
  if (args.length === 0 || args.includes('--help') || args[0] === 'help') {
    io.out(t(locale, 'help') + '\n');
    return 0;
  }
  try {
    const { command, seed, options } = parse(args, locale);
    io.out(JSON.stringify(commands[command](seed, options)) + '\n');
    return 0;
  } catch (error) {
    io.err((error instanceof TypeError ? error.message : t(locale, 'unexpected')) + '\n');
    return error instanceof TypeError ? 2 : 1;
  }
}

if (require.main === module) process.exitCode = run(process.argv.slice(2));

module.exports = { run };
