'use strict';

const dictionaries = {
  ja: {
    help: `使い方: node api/cli/index.js <simulate|batch|lineage> --seed <整数> [設定]
  simulate  一人の人生を生成
  batch     複数の人生を生成
  lineage   親子の人生を生成（--era past が必要）

共通設定: --locale ja|en, --era past|now|future, --method births|pop,
          --country <国コード>, --year <1950～2025>,
          --gentle true|false, --edu true|false, --stateless true|false
batch の設定: --count <1～100>
lineage の設定: --generations <1～3>
結果は標準出力に JSON で表示します。設定の誤りは標準エラーに表示します。
例: node api/cli/index.js simulate --seed 417 --locale ja`,
    command: 'simulate、batch、lineage のいずれかを指定してください。',
    flag: '不明な設定: {flag}',
    missing: '{flag} の値を指定してください。',
    duplicate: '{flag} は一度だけ指定してください。',
    seedRequired: '--seed を指定してください。',
    integer: '{flag} は 0 以上の整数で指定してください。',
    boolean: '{flag} は true または false で指定してください。',
    unexpected: '処理に失敗しました。'
  },
  en: {
    help: `Usage: node api/cli/index.js <simulate|batch|lineage> --seed <integer> [options]
  simulate  Generate one life
  batch     Generate multiple lives
  lineage   Generate connected lives (--era past required)

Common options: --locale ja|en, --era past|now|future, --method births|pop,
                --country <country code>, --year <1950–2025>,
                --gentle true|false, --edu true|false, --stateless true|false
Batch option: --count <1–100>
Lineage option: --generations <1–3>
The result is JSON on standard output. Input errors go to standard error.
Example: node api/cli/index.js simulate --seed 417 --locale en`,
    command: 'Choose simulate, batch, or lineage.',
    flag: 'Unknown option: {flag}',
    missing: 'Provide a value for {flag}.',
    duplicate: 'Use {flag} only once.',
    seedRequired: 'Provide --seed.',
    integer: '{flag} must be a nonnegative integer.',
    boolean: '{flag} must be true or false.',
    unexpected: 'The operation failed.'
  }
};

function t(locale, key, vars = {}) {
  return dictionaries[locale === 'en' ? 'en' : 'ja'][key]
    .replace(/\{([a-zA-Z]+)\}/g, (_, name) => String(vars[name]));
}

module.exports = { dictionaries, t };
