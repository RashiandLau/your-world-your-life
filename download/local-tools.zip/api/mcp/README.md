# 手元で使う MCP 接続 / Local MCP connection

## 日本語

この接続は、自分のパソコンで動く人生生成の中核を、MCP 対応アプリから使うためのものです。Node.js 18 以上が必要です。追加のパッケージは要りません。公開サーバーや通信口を開かず、標準入出力だけを使います。外部への通信、鍵、利用記録の送信、料金、利用回数の制限はありません。生成結果は計算上の人生であり、実在する人の予測ではありません。資料が足りない部分には推定が含まれます。

展開したフォルダで、次のコマンドを MCP アプリの起動設定に指定してください。設定欄が `command` と `args` に分かれている場合、`command` は `node`、`args` は `api/mcp/index.js` です。別の場所から起動するときは、ファイルの絶対パスを指定してください。

```sh
node api/mcp/index.js
```

通信には MCP `2025-06-18` の JSON-RPC を使います。標準入力に UTF-8 の JSON を一行ずつ送り、標準出力から一行ずつ受け取ります。標準出力に案内文は出しません。`initialize`、`ping`、`tools/list`、`tools/call` に対応します。`notifications/initialized` などの通知には返答しません。

読み取り専用の道具は三つです。

| 名前 | 内容 |
| --- | --- |
| `simulate_life` | 一人の人生と、年齢付きの出来事を返す |
| `batch_compare` | 複数の人生を生成する |
| `lineage` | 親子の記録をつなぐ |

いずれも `arguments` に `seed` と、必要に応じて `options` を渡します。`seed` は 0〜4294967295 の整数です。`options` の共通項目は `locale` (`ja` または `en`)、`era` (`past`、`now`、`future`)、`method` (`births` または `pop`)、`country` (小文字の3文字)、`year` (`past` のときだけ 1950〜2025)、`gentle`、`edu`、`stateless` です。`edu` は `now` のときだけ使えます。`batch_compare` は `options.count` に 1〜100、`lineage` は `options.generations` に 1〜3 を指定できます。系譜には `era: "past"` が必要です。省略時の値と結果の詳しい形は [中核の説明](../core/README.md)を参照してください。

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"simulate_life","arguments":{"seed":417,"options":{"locale":"ja"}}}}
```

成功時は `result.content[0].text` に JSON 形式の結果が入ります。入力の誤りや生成できない場合は `result.isError` が `true` になり、短い説明が `content` に入ります。人生の内容と契約の版は中核と同じです。同じ種、設定、資料なら結果は一致します。

## English

This connection lets an MCP client use the life simulation core on your own computer. It needs Node.js 18 or later and no additional packages. It opens no public server or network listener; it uses standard input and output only. It makes no external network calls and requires no key, account, fee, quota, or usage reporting. A result is a simulated life, not a prediction about a real person. Some data gaps are filled with estimates.

Set the command above as the launch command in your MCP client. Where the client has separate `command` and `args` fields, use `node` and `api/mcp/index.js`. Use an absolute path for the script if the client starts elsewhere.

The transport uses newline-delimited UTF-8 JSON-RPC under MCP protocol version `2025-06-18`. It responds to `initialize`, `ping`, `tools/list`, and `tools/call`. Notifications such as `notifications/initialized` receive no response. Standard output contains protocol messages only.

The three read-only tools are `simulate_life` (one life and age-stamped experiences), `batch_compare` (multiple lives), and `lineage` (connected parent and child records). Each takes `seed` and optional `options` inside `arguments`. The seed is an integer from 0 to 4294967295. Common options are `locale` (`ja` or `en`), `era` (`past`, `now`, `future`), `method` (`births` or `pop`), `country` (a lowercase three-letter code), `year` (1950–2025 with `past` only), and the booleans `gentle`, `edu`, and `stateless`. `edu` requires `now`. Set `options.count` to 1–100 for `batch_compare`; set `options.generations` to 1–3 for `lineage`, which requires `era: "past"`. See the [core documentation](../core/README.md) for defaults and result shape.

On success, `result.content[0].text` holds the JSON result. Invalid input or an unsuccessful simulation sets `result.isError` to `true` and returns a short explanation in `content`. The life data and contract version match the core. The same seed, options, and bundled data reproduce the same result.
