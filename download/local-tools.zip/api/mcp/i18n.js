'use strict';

const dictionaries = {
  ja: {
    server: '手元で動く人生生成',
    simulate: '種から一人の人生と、年齢付きの出来事を生成します。',
    batch: '一つの種から複数の人生を生成し、比べられる形で返します。',
    lineage: '親子の記録をつなぎ、最大三世代の人生を生成します。',
    seed: 'seed は 0 から 4294967295 までの整数にしてください。',
    options: 'options は設定のまとまりにしてください。',
    arguments: '引数は seed と options を含むまとまりにしてください。',
    unknownArgument: '使えない引数があります。',
    unknownTool: 'その道具は使えません。',
    invalidInput: '入力を確認してください。',
    failed: '人生を生成できませんでした。',
    invalidRequest: '要求の形が正しくありません。',
    methodNotFound: '要求された機能がありません。',
    parseError: 'JSON を読み取れませんでした。'
  },
  en: {
    server: 'Local life simulation',
    simulate: 'Generate one life and its age-stamped experiences from a seed.',
    batch: 'Generate multiple lives from one seed for comparison.',
    lineage: 'Connect parent and child records across up to three generations.',
    seed: 'seed must be an integer from 0 to 4294967295.',
    options: 'options must be an object of settings.',
    arguments: 'Arguments must be an object containing seed and options.',
    unknownArgument: 'An argument is not supported.',
    unknownTool: 'That tool is unavailable.',
    invalidInput: 'Check the input.',
    failed: 'Could not generate a life.',
    invalidRequest: 'Invalid request.',
    methodNotFound: 'Method not found.',
    parseError: 'Could not parse JSON.'
  }
};

function t(locale, key) {
  return dictionaries[locale === 'en' ? 'en' : 'ja'][key];
}
function both(key) {
  return dictionaries.ja[key] + ' / ' + dictionaries.en[key];
}

module.exports = { t, both };
