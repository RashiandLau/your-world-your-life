'use strict';

// MCP over local stdio: one JSON-RPC message per UTF-8 line.
const core = require('../core');
const { t, both } = require('./i18n');

const PROTOCOL_VERSION = '2025-06-18';
const SERVER_VERSION = '1.0.0';
const MAX_LINE_LENGTH = 4 * 1024 * 1024;
const hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = value => ({ type: 'text', text: value });

function optionsSchema(extra) {
  return {
    type: 'object',
    additionalProperties: false,
    properties: {
      locale: { type: 'string', enum: ['ja', 'en'] },
      era: { type: 'string', enum: ['past', 'now', 'future'] },
      method: { type: 'string', enum: ['births', 'pop'] },
      country: { type: 'string', pattern: '^[a-z]{3}$' },
      year: { type: 'integer', minimum: 1950, maximum: 2025 },
      gentle: { type: 'boolean' },
      edu: { type: 'boolean' },
      stateless: { type: 'boolean' },
      ...extra
    }
  };
}
function tool(name, descriptionKey, extra) {
  return {
    name,
    description: both(descriptionKey),
    inputSchema: {
      type: 'object',
      required: ['seed'],
      additionalProperties: false,
      properties: {
        seed: { type: 'integer', minimum: 0, maximum: 4294967295 },
        options: optionsSchema(extra)
      }
    },
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  };
}
const tools = [
  tool('simulate_life', 'simulate'),
  tool('batch_compare', 'batch', { count: { type: 'integer', minimum: 1, maximum: 100 } }),
  tool('lineage', 'lineage', { generations: { type: 'integer', minimum: 1, maximum: 3 } })
];
const operations = {
  simulate_life: core.simulate,
  batch_compare: core.batch,
  lineage: core.lineage
};

function rpcError(id, code, message) {
  return { jsonrpc: '2.0', id, error: { code, message } };
}
function rpcResult(id, result) {
  return { jsonrpc: '2.0', id, result };
}
function toolError(locale, key) {
  return { content: [text(t(locale, key))], isError: true };
}
function localeOf(args) {
  return isObject(args) && isObject(args.options) && args.options.locale === 'en' ? 'en' : 'ja';
}
function callTool(params) {
  const args = isObject(params) ? params.arguments : undefined;
  const locale = localeOf(args);
  if (!isObject(params) || typeof params.name !== 'string' || !hasOwn(operations, params.name)) {
    return toolError(locale, 'unknownTool');
  }
  if (!isObject(args)) return toolError(locale, 'arguments');
  if (Object.keys(args).some(key => key !== 'seed' && key !== 'options')) return toolError(locale, 'unknownArgument');
  if (!Number.isInteger(args.seed) || args.seed < 0 || args.seed > 0xffffffff) return toolError(locale, 'seed');
  if (args.options !== undefined && !isObject(args.options)) return toolError(locale, 'options');
  try {
    const result = operations[params.name](args.seed, args.options || {});
    return { content: [text(JSON.stringify(result))] };
  } catch (error) {
    // Core TypeErrors are its translated contract-validation failures.
    if (error instanceof TypeError) {
      return { content: [text(error.message || t(locale, 'invalidInput'))], isError: true };
    }
    return toolError(locale, 'failed');
  }
}
function handleMessage(message) {
  if (!isObject(message) || message.jsonrpc !== '2.0' || typeof message.method !== 'string' ||
      (hasOwn(message, 'id') && message.id !== null && typeof message.id !== 'string' &&
       !(typeof message.id === 'number' && Number.isInteger(message.id)))) {
    return rpcError(null, -32600, both('invalidRequest'));
  }
  if (!hasOwn(message, 'id')) return undefined; // Client notification.
  const id = message.id;
  switch (message.method) {
    case 'initialize':
      return rpcResult(id, {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'your-world-your-life-local', version: SERVER_VERSION, title: both('server') }
      });
    case 'ping':
      return rpcResult(id, {});
    case 'tools/list':
      return rpcResult(id, { tools });
    case 'tools/call':
      return rpcResult(id, callTool(message.params));
    default:
      return rpcError(id, -32601, both('methodNotFound'));
  }
}
function createLineProcessor(write) {
  let pending = '';
  let skipping = false;
  function emit(line) {
    if (line.endsWith('\r')) line = line.slice(0, -1);
    if (line.length === 0) return;
    let response;
    try {
      response = handleMessage(JSON.parse(line));
    } catch (_) {
      response = rpcError(null, -32700, both('parseError'));
    }
    if (response !== undefined) write(JSON.stringify(response) + '\n');
  }
  function push(chunk) {
    pending += chunk;
    let newline;
    while ((newline = pending.indexOf('\n')) !== -1) {
      const line = pending.slice(0, newline);
      pending = pending.slice(newline + 1);
      if (skipping) { skipping = false; continue; }
      if (Buffer.byteLength(line, 'utf8') > MAX_LINE_LENGTH) write(JSON.stringify(rpcError(null, -32700, both('parseError'))) + '\n');
      else emit(line);
    }
    if (Buffer.byteLength(pending, 'utf8') > MAX_LINE_LENGTH) {
      pending = '';
      skipping = true;
      write(JSON.stringify(rpcError(null, -32700, both('parseError'))) + '\n');
    }
  }
  return { push, end() { if (!skipping && pending.length) emit(pending); pending = ''; } };
}

if (require.main === module) {
  process.stdin.setEncoding('utf8');
  const processor = createLineProcessor(chunk => process.stdout.write(chunk));
  process.stdin.on('data', chunk => processor.push(chunk));
  process.stdin.on('end', () => processor.end());
}

module.exports = { PROTOCOL_VERSION, handleMessage, createLineProcessor };
