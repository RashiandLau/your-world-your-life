# 手元で使う人生生成 / Local life simulation tools

## 日本語

Node.js 18 以降を用意し、展開したフォルダで次のコマンドを実行します。追加のパッケージ、登録、鍵は要りません。

```sh
node api/cli/index.js simulate --seed 417 --locale ja
node api/cli/index.js batch --seed 417 --count 3 --locale ja
node api/cli/index.js lineage --seed 417 --era past --year 1960 --generations 2 --locale ja
node api/cli/index.js help
```

結果は標準出力に JSON で出ます。`simulate` は一人分の人生と年齢付きの出来事、`batch` は複数人分、`lineage` は親子の記録を返します。`lineage` は過去の出生年を指定してください。子の記録が条件に合わなければ、指定した世代数より短く終わります。`contractVersion` は [中核の説明](core/README.md)にある契約の版です。同じ版、種、設定、同梱資料を使えば結果を再現できます。資料や生成コードが変わると、同じ契約の版でも結果が変わる場合があります。

MCP 対応アプリから使う場合は、手元のプロセスとして `node` で `api/mcp/index.js` を起動するよう設定します。設定欄の形はアプリによって異なります。たとえば、コマンド欄を `node`、引数欄を `C:/path/to/repo/api/mcp/index.js` にします。MCP の通信には標準入力と標準出力を使います。対応する通信の版は `2025-06-18` です。`simulate_life`、`batch_compare`、`lineage` の三つの読み取り専用ツールを公開します。人生記録をファイルへ保存する操作はありません。

この実装は外部へ通信せず、公開用の待受口も開きません。利用回数の制限、課金、利用履歴の送信もありません。ただし、接続先の AI アプリが入力や結果をどう扱うかは、そのアプリの設定に従います。結果は架空の人生であり、実在する人の将来を示しません。統計のない部分には推定が含まれます。

## English

Install Node.js 18 or later and run these commands from the extracted folder. No extra package, account, or key is needed.

```sh
node api/cli/index.js simulate --seed 417 --locale en
node api/cli/index.js batch --seed 417 --count 3 --locale en
node api/cli/index.js lineage --seed 417 --era past --year 1960 --generations 2 --locale en
node api/cli/index.js help
```

The CLI writes JSON to stdout. `simulate` returns one life with age-stamped experiences; `batch` returns several lives; `lineage` follows recorded children. Lineage requires a past birth year and may stop before the requested generation if no child qualifies. The `contractVersion` field identifies the [core contract](core/README.md). The same contract version, seed, options, and bundled data reproduce a result. A later data or engine update can change results without changing the contract shape.

For an MCP host, configure a local process with command `node` and argument `C:/path/to/repo/api/mcp/index.js`, adjusted to your checkout. Host configuration formats vary. The server uses stdin and stdout, supports protocol version `2025-06-18`, and lists three read-only tools: `simulate_life`, `batch_compare`, and `lineage`. It does not save life records to files.

These tools make no network calls and open no public listener. There are no quotas, fees, or usage reports. The AI application you connect may handle inputs and results according to its own settings. The output describes simulated lives, not predictions about real people; gaps in the source data include estimates.
